﻿
namespace buoi07
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.label1 = new System.Windows.Forms.Label();
            this.imgLstExam = new System.Windows.Forms.ImageList(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.btnGame9 = new System.Windows.Forms.Button();
            this.btnGame6 = new System.Windows.Forms.Button();
            this.btnGame3 = new System.Windows.Forms.Button();
            this.btnGame8 = new System.Windows.Forms.Button();
            this.btnGame7 = new System.Windows.Forms.Button();
            this.btnGame5 = new System.Windows.Forms.Button();
            this.btnGame4 = new System.Windows.Forms.Button();
            this.btnGame2 = new System.Windows.Forms.Button();
            this.btnGame1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbStep = new System.Windows.Forms.Label();
            this.pctBoxExam = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctBoxExam)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(329, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Example";
            // 
            // imgLstExam
            // 
            this.imgLstExam.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLstExam.ImageStream")));
            this.imgLstExam.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLstExam.Images.SetKeyName(0, "M11.png");
            this.imgLstExam.Images.SetKeyName(1, "M12.png");
            this.imgLstExam.Images.SetKeyName(2, "M13.png");
            this.imgLstExam.Images.SetKeyName(3, "M14.png");
            this.imgLstExam.Images.SetKeyName(4, "M15.png");
            this.imgLstExam.Images.SetKeyName(5, "M16.png");
            this.imgLstExam.Images.SetKeyName(6, "M17.png");
            this.imgLstExam.Images.SetKeyName(7, "M18.png");
            this.imgLstExam.Images.SetKeyName(8, "M19.png");
            this.imgLstExam.Images.SetKeyName(9, "M20.png");
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(36, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Số bước đi:";
            // 
            // btnGame9
            // 
            this.btnGame9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame9.BackColor = System.Drawing.Color.Red;
            this.btnGame9.Location = new System.Drawing.Point(222, 198);
            this.btnGame9.Name = "btnGame9";
            this.btnGame9.Size = new System.Drawing.Size(73, 75);
            this.btnGame9.TabIndex = 5;
            this.btnGame9.UseVisualStyleBackColor = false;
            this.btnGame9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame9_KeyDown);
            // 
            // btnGame6
            // 
            this.btnGame6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame6.BackColor = System.Drawing.Color.Blue;
            this.btnGame6.Location = new System.Drawing.Point(222, 117);
            this.btnGame6.Name = "btnGame6";
            this.btnGame6.Size = new System.Drawing.Size(73, 75);
            this.btnGame6.TabIndex = 6;
            this.btnGame6.UseVisualStyleBackColor = false;
            this.btnGame6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame6_KeyDown);
            // 
            // btnGame3
            // 
            this.btnGame3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame3.BackColor = System.Drawing.Color.Green;
            this.btnGame3.Location = new System.Drawing.Point(222, 36);
            this.btnGame3.Name = "btnGame3";
            this.btnGame3.Size = new System.Drawing.Size(73, 75);
            this.btnGame3.TabIndex = 7;
            this.btnGame3.UseVisualStyleBackColor = false;
            this.btnGame3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame3_KeyDown);
            // 
            // btnGame8
            // 
            this.btnGame8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame8.BackColor = System.Drawing.Color.Blue;
            this.btnGame8.Location = new System.Drawing.Point(140, 198);
            this.btnGame8.Name = "btnGame8";
            this.btnGame8.Size = new System.Drawing.Size(73, 75);
            this.btnGame8.TabIndex = 8;
            this.btnGame8.UseVisualStyleBackColor = false;
            this.btnGame8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame8_KeyDown);
            // 
            // btnGame7
            // 
            this.btnGame7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame7.BackColor = System.Drawing.Color.Green;
            this.btnGame7.Location = new System.Drawing.Point(61, 198);
            this.btnGame7.Name = "btnGame7";
            this.btnGame7.Size = new System.Drawing.Size(73, 75);
            this.btnGame7.TabIndex = 9;
            this.btnGame7.UseVisualStyleBackColor = false;
            this.btnGame7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame7_KeyDown);
            // 
            // btnGame5
            // 
            this.btnGame5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame5.BackColor = System.Drawing.Color.Green;
            this.btnGame5.Location = new System.Drawing.Point(140, 117);
            this.btnGame5.Name = "btnGame5";
            this.btnGame5.Size = new System.Drawing.Size(73, 75);
            this.btnGame5.TabIndex = 10;
            this.btnGame5.UseVisualStyleBackColor = false;
            this.btnGame5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame5_KeyDown);
            // 
            // btnGame4
            // 
            this.btnGame4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame4.BackColor = System.Drawing.Color.Blue;
            this.btnGame4.Location = new System.Drawing.Point(61, 117);
            this.btnGame4.Name = "btnGame4";
            this.btnGame4.Size = new System.Drawing.Size(73, 75);
            this.btnGame4.TabIndex = 11;
            this.btnGame4.UseVisualStyleBackColor = false;
            this.btnGame4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame4_KeyDown);
            // 
            // btnGame2
            // 
            this.btnGame2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame2.BackColor = System.Drawing.Color.Red;
            this.btnGame2.Location = new System.Drawing.Point(140, 36);
            this.btnGame2.Name = "btnGame2";
            this.btnGame2.Size = new System.Drawing.Size(73, 75);
            this.btnGame2.TabIndex = 12;
            this.btnGame2.UseVisualStyleBackColor = false;
            this.btnGame2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame2_KeyDown);
            // 
            // btnGame1
            // 
            this.btnGame1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGame1.BackColor = System.Drawing.Color.White;
            this.btnGame1.Location = new System.Drawing.Point(61, 36);
            this.btnGame1.Name = "btnGame1";
            this.btnGame1.Size = new System.Drawing.Size(73, 75);
            this.btnGame1.TabIndex = 13;
            this.btnGame1.UseVisualStyleBackColor = false;
            this.btnGame1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnGame1_KeyDown);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(255)))), ((int)(((byte)(231)))));
            this.label3.Location = new System.Drawing.Point(305, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 286);
            this.label3.TabIndex = 14;
            this.label3.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbStep
            // 
            this.lbStep.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbStep.AutoSize = true;
            this.lbStep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStep.ForeColor = System.Drawing.SystemColors.Control;
            this.lbStep.Location = new System.Drawing.Point(141, 325);
            this.lbStep.Name = "lbStep";
            this.lbStep.Size = new System.Drawing.Size(19, 20);
            this.lbStep.TabIndex = 4;
            this.lbStep.Text = "0";
            // 
            // pctBoxExam
            // 
            this.pctBoxExam.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pctBoxExam.BackgroundImage = global::buoi07.Properties.Resources.M11;
            this.pctBoxExam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pctBoxExam.Location = new System.Drawing.Point(333, 33);
            this.pctBoxExam.Name = "pctBoxExam";
            this.pctBoxExam.Size = new System.Drawing.Size(240, 240);
            this.pctBoxExam.TabIndex = 2;
            this.pctBoxExam.TabStop = false;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.SystemColors.Control;
            this.btnStart.Image = global::buoi07.Properties.Resources._25263_here_orange_start_icon;
            this.btnStart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStart.Location = new System.Drawing.Point(246, 298);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(124, 74);
            this.btnStart.TabIndex = 15;
            this.btnStart.Text = "Start";
            this.btnStart.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.ClientSize = new System.Drawing.Size(639, 382);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnGame9);
            this.Controls.Add(this.btnGame6);
            this.Controls.Add(this.btnGame3);
            this.Controls.Add(this.btnGame8);
            this.Controls.Add(this.btnGame7);
            this.Controls.Add(this.btnGame5);
            this.Controls.Add(this.btnGame4);
            this.Controls.Add(this.btnGame2);
            this.Controls.Add(this.btnGame1);
            this.Controls.Add(this.lbStep);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pctBoxExam);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Game";
            this.Text = "Game";
            this.Load += new System.EventHandler(this.Game_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctBoxExam)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pctBoxExam;
        private System.Windows.Forms.ImageList imgLstExam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGame9;
        private System.Windows.Forms.Button btnGame6;
        private System.Windows.Forms.Button btnGame3;
        private System.Windows.Forms.Button btnGame8;
        private System.Windows.Forms.Button btnGame7;
        private System.Windows.Forms.Button btnGame5;
        private System.Windows.Forms.Button btnGame4;
        private System.Windows.Forms.Button btnGame2;
        private System.Windows.Forms.Button btnGame1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbStep;
        private System.Windows.Forms.Button btnStart;
    }
}