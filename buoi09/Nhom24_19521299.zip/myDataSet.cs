﻿namespace WindowsFormsClass.Buoi09
{


    partial class myDataSet
    {
    }
}
