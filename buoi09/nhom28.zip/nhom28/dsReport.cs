﻿namespace buoi09
{


    partial class dsReport
    {
    }
}
